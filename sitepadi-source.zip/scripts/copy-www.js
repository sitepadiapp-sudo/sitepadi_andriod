// Copies the source app files into www/, then run `npx cap sync`
// to push them into android/ (and ios/).
//
// Note: this does NOT touch www/vendor/ — that's the local bundle of
// Firebase SDK, jsPDF, XLSX, Lucide, and fonts (previously loaded from
// CDNs at runtime, now bundled locally so the app works fully offline
// on first launch). vendor/ only needs regenerating if you bump one of
// those library versions — see README for how it was built.
//
// Usage: node scripts/copy-www.js /path/to/source/dir
// Defaults to the current directory if no path is given.
const fs = require('fs');
const path = require('path');

const srcDir = process.argv[2] || '.';
const files = ['index.html', 'privacy-policy.html', 'terms-of-service.html', 'delete-account.html'];
const wwwDir = path.join(__dirname, '..', 'www');

for (const f of files) {
  const src = path.join(srcDir, f);
  const dest = path.join(wwwDir, f);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, dest);
    console.log(`Copied ${f}`);
  } else {
    console.warn(`Skipped ${f} (not found in ${srcDir})`);
  }
}
console.log('\nDone. Now run: npx cap sync');
