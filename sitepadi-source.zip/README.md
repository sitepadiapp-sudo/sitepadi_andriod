# SitePadi — Capacitor Project

This wraps `www/index.html` (the SitePadi app) in a native shell for
Android and iOS via Capacitor.

## Building the APK without Android Studio (GitHub Actions)
If your machine can't run Android Studio (it's a heavy install — SDK,
emulator, several GB), this project includes a GitHub Actions
workflow (`.github/workflows/build-android.yml`) that builds the APK
on GitHub's own servers instead of your computer. You only need a
browser.

1. Create a new repository on [github.com](https://github.com) (any
   name, e.g. `sitepadi-app`) — Public is fine and free; Private also
   works but check GitHub's free-tier Actions minutes if so.
2. Get this project's files into that repo. The easiest way without
   using git commands: install **GitHub Desktop**
   ([desktop.github.com](https://desktop.github.com)) — it's a simple
   app, not a terminal — point it at the unzipped `sitepadi-capacitor`
   folder, and use its "Publish repository" button.
3. On GitHub's website, open the repo → **Actions** tab. The build
   starts automatically after the first push. If it doesn't, click
   **"Build Android APK"** in the left list → **"Run workflow"**.
4. Wait a few minutes (Android builds aren't instant). When the run
   finishes with a green checkmark, open it and scroll to
   **Artifacts** at the bottom — `sitepadi-debug-apk` is a downloadable
   `.zip` containing the actual `.apk` inside. Unzip it and you have
   an installable app.
5. This produces a **debug build** — installs and runs fine for
   testing, but isn't signed for the Play Store. That's a separate,
   later step (see "Known gaps" below).

Nothing about this needs Android Studio, a Mac, or a powerful laptop
— the actual compiling happens on GitHub's machines, not yours.

## What's already done
- **App icon & splash screen** — real branded assets, replacing
  Capacitor's generic default icon. Built from `SitePadi-logo.png`
  (the hard hat + "S" block mark): the mark was isolated with a clean
  transparent background (verified — interior white highlight strokes
  preserved, only the outer background removed), then placed on a
  white rounded-square "plate" inset within a brand-orange
  (`#FF7A00`) background — needed because the mark itself is mostly
  orange and nearly disappeared when placed directly on an orange
  background; the white plate restores contrast. Verified legible at
  actual 48px home-screen size before generating the full set.
  - Android: legacy `ic_launcher`/`ic_launcher_round` at all 5
    densities (flat, orange background baked in) + adaptive icon
    `ic_launcher_foreground` at all 5 densities (transparent, sized
    to the safe zone) + `ic_launcher_background` color set to
    `#FF7A00` to match
  - iOS: single 1024×1024 `AppIcon-512@2x.png` (opaque, no alpha —
    Apple requires this), matching the modern single-size
    `Contents.json` spec
  - Splash screens (both platforms, all densities/orientations):
    full logo lockup (mark + "SitePadi" wordmark + tagline) centered
    on white, matching the source artwork's own background so no
    recoloring or contrast issues
  - **Note:** the in-app header logo (login/wizard/PIN screens inside
    `index.html`) has also been updated to match — see
    `www/vendor/brand/logo-mark.png` below.

- **In-app header logo** — the three places `index.html` shows a
  small logo mark (auth screen, onboarding wizard, PIN/login screen)
  previously used a hand-drawn placeholder SVG unrelated to the real
  brand mark. All three now use the actual hard-hat logo: a small
  reusable asset (`www/vendor/brand/logo-mark.png` — mark on a
  transparent-backed white plate, same design language as the app
  icon) dropped into the existing navy/orange CSS boxes via `<img>`,
  so no colors needed hardcoding per-instance. Verified on both
  backgrounds and at actual in-app size (32–60px) in a real browser
  before finalizing — screenshots confirmed legible on all three
  screens.
- `capacitor.config.ts` — app ID `com.sitepadi.app`, app name `SitePadi`,
  matching the product IDs already used in the app's billing code
  (`com.sitepadi.pro.monthly`, etc.)
- `android/` — full native Android project, ready to open in Android Studio
- `ios/` — full native Xcode project, ready to open in Xcode (needs a Mac)
- `www/` — the four app HTML files (index, privacy-policy,
  terms-of-service, delete-account), already copied into both native
  projects' asset folders
- `www/vendor/` — Firebase SDK, jsPDF, XLSX, Lucide icons, and fonts
  (Bebas Neue, Sora, DM Mono), all bundled locally instead of loaded
  from CDNs at runtime. `index.html` loads these first and only falls
  back to a CDN if the local copy is somehow missing. This is what
  makes auth, PDF/Excel export, icons, and fonts actually work on
  first launch with no signal — matching the app's offline-first
  pitch. Verified in a headless browser with network access removed:
  every script/font request resolved from `vendor/`, zero failed
  requests, app rendered correctly.
- **Google Sign-In** — native flow wired in (see below)
- **`localStorage` → durable native storage** — every `localStorage.*`
  call in `index.html` now goes through an `AppStorage` wrapper.
  On native it's backed by `@capacitor/preferences` (survives
  Android's WebView storage clearing under low-disk pressure, and is
  included in system backups) via a synchronous in-memory cache
  that's hydrated from Preferences before `boot()`'s first read — so
  nothing else in the app had to change to be "async-aware." Web is
  untouched, still plain `localStorage`.
- **`window.open()` → in-app browser** — external links now go
  through an `openExternal()` helper: `http(s)` links use
  `@capacitor/browser` on native (has its own close button, unlike a
  bare `window.open` which can strand the user), `mailto:`/`tel:`
  links go straight to the OS handler. Web unchanged.
- **Android hardware back button** — registers a `backButton`
  listener via `@capacitor/app` that closes whichever modal/overlay
  is open (mapped from the app's own 11 open/close function pairs),
  steps back a wizard step during onboarding, jumps to the Log tab
  from any other tab, and finally does a standard double-press-to-exit
  once there's nowhere left to go. No-op on web/iOS.
- **RevenueCat** — `@revenuecat/purchases-capacitor` installed and
  linked into both native projects. `RevenueCatService` in
  `index.html` handles configure/identity-linking/entitlement-sync/
  purchase/restore; `BillingService.startPurchase()` and
  `restorePurchases()` call the real store flow when active, and the
  upgrade screen pulls real store-localized prices via
  `getOfferings()` instead of the hardcoded ₦ price. Everything is
  gated behind a single `REVENUECAT_ENABLED` constant (currently
  `false`) — until that's flipped on, native builds keep using the
  exact same demo-activate flow as web, so this is safe to ship as-is
  and turn on later. Verified in a browser: every RevenueCat call
  safely no-ops with `REVENUECAT_ENABLED = false`, and the existing
  demo upgrade flow (confirm dialog → instant Pro activation) still
  works unchanged.

## What you need to do next (needs your machine, not this sandbox)

### Android
1. Install [Android Studio](https://developer.android.com/studio)
2. `npx cap open android` — opens the project in Android Studio
3. Let Gradle sync (first sync downloads the Android SDK components it needs)
4. Run on an emulator or a plugged-in device to sanity-check it boots
5. Specifically worth checking on-device: the back button behavior
   (item above) — I traced it carefully against the app's own code
   but couldn't press an actual hardware back button from this sandbox

### iOS (needs a Mac)
1. Install Xcode from the Mac App Store
2. `npx cap open ios` — opens the project in Xcode
3. Set your Apple Developer signing team in the project settings
4. Run on the simulator or a device

## Turning RevenueCat on (once you're ready to sell real subscriptions)
**Progress so far:** RevenueCat project "SitePadi" created, Android app
added (package `com.sitepadi.app`), and the real Android public API key
is already in place in `index.html` (`REVENUECAT_API_KEYS.android`).
Still needed:
- iOS app + its API key (same process, once there's an iOS side to test)
- Service account credentials JSON (skipped during app creation —
  needed later for automatic transaction validation, not urgent yet)
- Everything below is still blocked on Play Console: **Google Play
  won't let you create subscription products until a build has been
  uploaded to at least a closed testing track** — i.e., this needs the
  release-signing step done first.

1. Once you have a signed release build uploaded to Play Console,
   create subscription products there: `com.sitepadi.pro.monthly` /
   `com.sitepadi.pro.yearly` (already registered as product IDs
   elsewhere in this codebase). Then import them into the RevenueCat
   project already created above.
2. Create one Entitlement (default ID used here: `pro_access` — or
   change `REVENUECAT_ENTITLEMENT_ID` in `index.html` to match
   whatever you name it) and attach both Pro products to it.
3. Create an Offering with `monthly` and `annual` packages pointing
   at those two products — `renderPricingOptions()` in `index.html`
   expects exactly those two package identifiers.
4. iOS: repeat the "add app" step in RevenueCat for App Store Connect,
   and replace `REPLACE_ME_IOS_RC_API_KEY` in `index.html` the same
   way the Android key was already added.
5. Flip `REVENUECAT_ENABLED` from `false` to `true` in `index.html`.
6. Re-run `node scripts/copy-www.js` + `npx cap sync`, then test the
   full purchase → cancel → restore-on-new-device lifecycle in each
   store's sandbox before submitting for review.

## Updating the app after code changes
Whenever `index.html` (or the other HTML files) changes:
```
node scripts/copy-www.js /path/to/updated/files
npx cap sync
```
`cap sync` copies `www/` into both `android/` and `ios/` and updates
native dependencies. Do this every time before rebuilding.

### Updating a vendor library later (new Firebase/jsPDF/XLSX/Lucide version)
The vendor bundle was built by installing the exact same pinned
versions the app already used from npm (all four ship the same file
names/builds that the CDNs were serving) and copying the relevant
dist files into `www/vendor/`:
```
npm install firebase@<version> lucide@<version> jspdf@<version> xlsx@<version>
# then copy the relevant dist/ files from node_modules into www/vendor/
# (see git history / prior conversation notes for the exact file map)
npx cap sync
```
Fonts came from the `@fontsource/*` npm packages (Google-Fonts-sourced,
npm-redistributed) rather than fonts.googleapis.com directly.

## Known gaps before this is store-ready
1. **Google Sign-In** — ✅ wired in. `index.html` now branches on
   `Capacitor.isNativePlatform()`: native uses
   `@southdevs/capacitor-google-auth` to get a token from the OS-level
   Google Sign-In flow, then hands it to the existing Firebase Auth
   compat SDK (`signInWithCredential`) — same as before, just a
   different way of getting the token. Web is untouched (still popup
   → redirect fallback).

   A **stable debug keystore is now committed** at
   `android/app/debug.keystore` (fixed credentials: alias
   `androiddebugkey`, password `android` — standard debug-key
   convention) and `android/app/build.gradle` is configured to always
   use it. This matters because Google Sign-In is tied to a specific
   SHA-1 fingerprint — without a fixed keystore, a fresh CI runner
   could generate a different one on every build, silently breaking
   sign-in each time. Its fingerprints (register these in Firebase —
   see next step):
   ```
   SHA1:   3F:4E:FA:BF:E6:39:28:94:C6:99:55:2D:B3:BD:BD:3C:10:0F:DA:B9
   SHA256: 81:1F:3F:40:5C:52:73:AD:CF:25:3D:60:AA:9A:B3:DD:D1:3E:68:8A:7D:48:F6:FC:DB:B7:77:1E:B4:47:FE:7E
   ```
   This keystore is debug-only — never use it for a Play Store release
   build, which needs its own separately-generated, securely-stored
   release keystore.

   **Still needed from you before this works on a real device:**
   - Firebase Console → Project Settings → your Android app (add one
     if it doesn't exist yet, package name `com.sitepadi.app`) → add
     the SHA-1 above as a fingerprint.
   - Replace `REPLACE_ME.apps.googleusercontent.com` in
     `capacitor.config.ts` AND `android/app/src/main/res/values/strings.xml`
     with your Firebase project's real Web Client ID (Firebase Console →
     Authentication → Sign-in method → Google → Web SDK configuration).
     This one I can't generate for you — it's specific to your Firebase
     project.
   - iOS: download `GoogleService-Info.plist` from Firebase Console →
     Project Settings → your iOS app, add it to the Xcode project, then
     replace `REPLACE_ME_REVERSED_CLIENT_ID` in `ios/App/App/Info.plist`
     with that file's `REVERSED_CLIENT_ID` value.
   - Re-run `npx cap sync` after any of the above changes.
2. **CDN-loaded libraries** — ✅ done, see "What's already done" above.
3. **`localStorage`, `window.open()`, Android back button** — ✅ all
   done, see "What's already done" above.
4. **RevenueCat** — ✅ wired in, inactive until you complete the setup
   steps above ("Turning RevenueCat on").
5. A note on `xlsx@0.18.5`: `npm audit` flags known advisories against
   older `xlsx` versions (prototype pollution / ReDoS in the *parsing*
   path). The app only ever *writes* XLSX files (exports), never parses
   untrusted ones, so this is low-risk here — but worth knowing if you
   later add "import from Excel" as a feature.

Everything on the original readiness checklist is now done. What's
left is entirely credentials/store-console work only you can do —
Google Sign-In's Firebase keys and Android SHA-1 fingerprints, and
RevenueCat's dashboard setup + API keys.
