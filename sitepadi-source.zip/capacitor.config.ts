import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sitepadi.app',
  appName: 'SitePadi',
  webDir: 'www',
  plugins: {
    GoogleAuth: {
      scopes: ['profile', 'email'],
      // REPLACE ME: this must be your Firebase project's Web Client ID —
      // Firebase Console → Authentication → Sign-in method → Google →
      // "Web SDK configuration" → Web client ID. It already exists once
      // Google Sign-In is enabled for the web app; this just reuses it
      // for native sign-in too so both issue tokens Firebase Auth accepts.
      serverClientId: '211099277111-d7nrolgkmi1nde88fon5cs01f39r40sq.apps.googleusercontent.com',
      forceCodeForRefreshToken: true,
    },
  },
};

export default config;
